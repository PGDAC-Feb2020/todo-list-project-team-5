import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-todolist',
  templateUrl: './todolist.component.html',
  styleUrls: ['./todolist.component.css'],
})
export class TodolistComponent implements OnInit {
  public title = 'hello-client';

  public uiInvalidCredential = false;

  public fbFormGroup = this.fb.group({
    Task: ['', Validators.required],
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient
  ) {}

  ngOnInit(): void {}

  async create() {
    const data = this.fbFormGroup.value;
    const url = 'http://localhost:3050/addtask';

    await this.http.post(url, data).toPromise();

    // this.router.navigate(['login']);
  }
}
